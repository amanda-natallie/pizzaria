phpunit $* --verbose --bootstrap `dirname $0`/test-init.php `dirname $0`/tests
